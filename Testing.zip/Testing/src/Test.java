import java.net.StandardSocketOptions;

public class Test {

    public static void main(String[] args) {
        //System.out.println("jeevana");
        /*System.out.println(10+20);
        System.out.println(10-20);
         */
        //int a;
        //a=100;
        /*int a=100;
        System.out.println(a);
        a=300;
        System.out.println(a);
*/
        //Approach 1 -- if all the variables belongs to different data type
      /*  int a=10;
        int b=20;
        int c=30;
*/
        //Approach 2 -- if all the variables belongs to same data type
       /*     int a,b,c;
        a=1;
        b=2;
        c=3;
        */
        //Appraach 3 -- if all the variables belongs to same data type
       /* int a=100,b=200,c=300;
        System.out.println("the value of a is:"+a);
        System.out.println("the value of b is:"+b);
        System.out.println("the value of c is:"+c);
        System.out.println(a+b+c);
        System.out.println(a+ " "+b+" "+c);
        */
int a=10, b=2;
        System.out.println("the value of a is:"+a);
        System.out.println("the value of b is:"+b);
        System.out.println(a+b);
        System.out.println("the value of a and b is:"+(a+b));
byte by=125;
System.out.println(by);
short sh=2345;
System.out.println(sh);
long l=6543345L;
System.out.println(l);

// Decimal data types
float itemprice=15.4f;
System.out.println(itemprice);
double dbl=1234.5433;
System.out.println(dbl);
char grade='A';
System.out.println(grade);
String name= "JOHN";
System.out.println("name");
boolean bl=true;
System.out.println(bl);






}
}