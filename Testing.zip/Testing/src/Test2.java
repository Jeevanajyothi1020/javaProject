public class Test2 {
    public static void main(String[] args) {
       /* int person_age=15;
        if(person_age>=20)
        {
            System.out.println("Eligible for vote");
            }
            */

      /*  if(person_age>=20)
        {
            System.out.println("Eligible for vote");
        }
        else {
            System.out.println("Not eligible for vote");
        } */
        /*int num=17;
        if(num%2==0)
        {
            System.out.println("even");
        }
        else
        {
            System.out.println("odd");
        } */
       /* int a;
        if(a=5//6)
        {
            System.out.println("True");
        }
        else
        {
            System.out.println("false");
        } */
        /*int num=2;
        if(num>0)
        {
            System.out.println("positive number");
        }
        else if(num<0)
        {
            System.out.println("negative number");
        }
        else
        {
            System.out.println("zero");
        } */
        // Largest number
    /*    int a=100,b=200,c=30;
if (a>b && a>c)
{
    System.out.println("a is largest number" +a);
}
else if (b>a && b>c)
{
    System.out.println("b is largest number" +b);
}
else
{
    System.out.println("c is largest number" +c);
} */
        /*if(false)
        {
            System.out.println(1);
        }
        else
        {
            System.out.println(2);
        } */
        int weekno = 8;
        switch (weekno) {
            case 1:
                System.out.println("sunday");
                break;
            case 2:
                System.out.println("monday");
                break;
            case 3:
                System.out.println("tuesday");
                break;
            case 4:
                System.out.println("wednesday");
                break;
            case 5:
                System.out.println("thursday");
                break;
            case 6:
                System.out.println("friday");
                break;
            case 7:
                System.out.println("saturday");
                break;
            default:
                System.out.println("invalid");

        }
        String weekname = "tuesday";
        switch (weekname) {
            case "sunday":
                System.out.println(1);
                break;
            case "monday":
                System.out.println(2);
                break;
            case "tuesday":
                System.out.println(3);
                break;
            case "wednesday":
                System.out.println(4);
                break;
            case "thursday":
                System.out.println(5);
                break;
            case "friday":
                System.out.println(6);
                break;
            case "saturday":
                System.out.println(7);
                break;
            default:
                System.out.println(8);
        }
    }}



