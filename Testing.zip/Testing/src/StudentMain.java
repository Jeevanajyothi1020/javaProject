public class StudentMain
{
    public static void main(String[] args) {
      //  student stu=new student();
     /*   stu.sid=100;
        stu.sname="jj";
        stu.grad='O';
        stu.printStudentData();

        // method 2
        stu.setStudentData(100,"jeevanaj",'A');
        stu.printStudentData(); */
        //using constructor
        student stu=new student(100,"jeeva",'A');
        stu.printStudentData();
    }
}
